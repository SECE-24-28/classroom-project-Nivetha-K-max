const dotenv = require('dotenv');
const mongoose = require('mongoose');
const jwt = require('jsonwebtoken');
const http = require('http');
const User = require('./src/models/User');

dotenv.config();

(async () => {
  try {
    await mongoose.connect(process.env.MONGO_URI, { useNewUrlParser: true, useUnifiedTopology: true });

    const user = await User.findOne({ email: 'john@example.com' });
    if (!user) {
      console.error('User not found');
      process.exit(1);
    }

    const token = jwt.sign({ id: user._id }, process.env.JWT_SECRET, { expiresIn: '30d' });

    const options = {
      hostname: '127.0.0.1',
      port: process.env.PORT || 5000,
      path: '/api/movies',
      method: 'GET',
      headers: {
        'Authorization': `Bearer ${token}`
      }
    };

    const req = http.request(options, (res) => {
      let body = '';
      res.on('data', (chunk) => (body += chunk));
      res.on('end', () => {
        console.log('Status:', res.statusCode);
        try {
          const parsed = JSON.parse(body);
          console.log('Response:', JSON.stringify(parsed, null, 2));
        } catch (e) {
          console.log('Raw response:', body);
        }
        process.exit(0);
      });
    });

    req.on('error', (err) => {
      console.error('Request error:', err.message);
      process.exit(1);
    });

    req.end();
  } catch (err) {
    console.error(err);
    process.exit(1);
  }
})();

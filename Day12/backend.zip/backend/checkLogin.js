const dotenv = require('dotenv');
const mongoose = require('mongoose');
const User = require('./src/models/User');
const bcrypt = require('bcryptjs');

dotenv.config();

(async () => {
  try {
    await mongoose.connect(process.env.MONGO_URI, { useNewUrlParser: true, useUnifiedTopology: true });
    console.log('Connected to DB');

    const email = 'john@example.com';
    const plain = 'password123';

    const user = await User.findOne({ email }).select('+password');
    if (!user) {
      console.log('User not found:', email);
      process.exit(0);
    }

    console.log('User found:', user.email);
    console.log('Stored hashed password:', user.password);

    const match = await bcrypt.compare(plain, user.password);
    console.log('Plain password matches hashed password?', match);

    process.exit(0);
  } catch (err) {
    console.error(err);
    process.exit(1);
  }
})();

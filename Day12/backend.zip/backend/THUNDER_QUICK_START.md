# 🎯 Quick Thunder Client Setup

## ✅ Step 1: Install Thunder Client
- Open VS Code
- Go to Extensions (Ctrl+Shift+X)
- Search "Thunder Client"
- Click Install

## ✅ Step 2: Open Thunder Client
- Click Thunder Client icon in left sidebar (lightning bolt)

## ✅ Step 3: Test Endpoints

### Login First (Get Token)
```
POST http://localhost:5000/api/auth/login
Content-Type: application/json

{
  "email": "john@example.com",
  "password": "password123"
}
```

**Response:** Copy the `token` value

### Get All Movies
```
GET http://localhost:5000/api/movies
Authorization: Bearer [PASTE_TOKEN_HERE]
```

### Add New Movie
```
POST http://localhost:5000/api/movies
Authorization: Bearer [PASTE_TOKEN_HERE]
Content-Type: application/json

{
  "title": "Interstellar",
  "genre": "Sci-Fi",
  "year": 2014,
  "status": "unwatched"
}
```

### Update Movie (Change Status)
```
PUT http://localhost:5000/api/movies/[MOVIE_ID_FROM_GET]
Authorization: Bearer [PASTE_TOKEN_HERE]
Content-Type: application/json

{
  "status": "watched"
}
```

### Delete Movie
```
DELETE http://localhost:5000/api/movies/[MOVIE_ID_FROM_GET]
Authorization: Bearer [PASTE_TOKEN_HERE]
```

---

## 📊 Sample Data Ready

**User 1:** john@example.com / password123
**User 2:** jane@example.com / password456

Both users have 3-4 movies already added!

---

## 🔑 How to Use Token in Thunder Client

1. After login, you get a token
2. Click on the Authorization header input
3. Paste: `Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...`
4. All protected requests will use this token

---

**Server is running on http://localhost:5000** ✅

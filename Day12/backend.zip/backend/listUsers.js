const dotenv = require('dotenv');
const mongoose = require('mongoose');
const User = require('./src/models/User');

dotenv.config();

(async () => {
  try {
    await mongoose.connect(process.env.MONGO_URI, { useNewUrlParser: true, useUnifiedTopology: true });
    console.log('Connected to DB');

    const users = await User.find({});
    console.log('Users count:', users.length);
    users.forEach(u => {
      console.log('- ', u.email, '|', u.name);
    });

    process.exit(0);
  } catch (err) {
    console.error(err);
    process.exit(1);
  }
})();

const Movie = require('../models/Movie');

// Add movie to watchlist
const addMovie = async (req, res) => {
  try {
    const { title, genre, year, status } = req.body;
    const userId = req.user.id;

    // Validation
    if (!title || !genre || !year) {
      return res.status(400).json({
        success: false,
        message: 'Please provide title, genre, and year'
      });
    }

    // Validate status if provided
    if (status && !['watched', 'unwatched'].includes(status)) {
      return res.status(400).json({
        success: false,
        message: 'Status must be either "watched" or "unwatched"'
      });
    }

    // Create movie
    const movie = await Movie.create({
      user: userId,
      title,
      genre,
      year,
      status: status || 'unwatched'
    });

    res.status(201).json({
      success: true,
      message: 'Movie added to watchlist',
      movie
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message
    });
  }
};

// Get user's watchlist
const getMovies = async (req, res) => {
  try {
    const userId = req.user.id;

    const movies = await Movie.find({ user: userId }).sort({ createdAt: -1 });

    res.status(200).json({
      success: true,
      message: 'Movies retrieved successfully',
      count: movies.length,
      movies
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message
    });
  }
};

// Update movie status
const updateMovie = async (req, res) => {
  try {
    const { id } = req.params;
    const userId = req.user.id;
    const updateData = req.body;

    // Validate status if provided
    if (updateData.status && !['watched', 'unwatched'].includes(updateData.status)) {
      return res.status(400).json({
        success: false,
        message: 'Status must be either "watched" or "unwatched"'
      });
    }

    // Find movie and verify ownership
    let movie = await Movie.findById(id);

    if (!movie) {
      return res.status(404).json({
        success: false,
        message: 'Movie not found'
      });
    }

    if (movie.user.toString() !== userId) {
      return res.status(403).json({
        success: false,
        message: 'Not authorized to update this movie'
      });
    }

    // Update movie
    movie = await Movie.findByIdAndUpdate(id, updateData, {
      new: true,
      runValidators: true
    });

    res.status(200).json({
      success: true,
      message: 'Movie updated successfully',
      movie
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message
    });
  }
};

// Delete movie from watchlist
const deleteMovie = async (req, res) => {
  try {
    const { id } = req.params;
    const userId = req.user.id;

    // Find movie and verify ownership
    const movie = await Movie.findById(id);

    if (!movie) {
      return res.status(404).json({
        success: false,
        message: 'Movie not found'
      });
    }

    if (movie.user.toString() !== userId) {
      return res.status(403).json({
        success: false,
        message: 'Not authorized to delete this movie'
      });
    }

    // Delete movie
    await Movie.findByIdAndDelete(id);

    res.status(200).json({
      success: true,
      message: 'Movie deleted successfully'
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message
    });
  }
};

module.exports = {
  addMovie,
  getMovies,
  updateMovie,
  deleteMovie
};

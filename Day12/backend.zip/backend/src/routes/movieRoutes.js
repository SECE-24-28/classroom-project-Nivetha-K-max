const express = require('express');
const authMiddleware = require('../middleware/authMiddleware');
const {
  addMovie,
  getMovies,
  updateMovie,
  deleteMovie
} = require('../controllers/movieController');

const router = express.Router();

// Apply auth middleware to all movie routes
router.use(authMiddleware);

// POST /api/movies - Add movie
router.post('/', addMovie);

// GET /api/movies - Get all movies for user
router.get('/', getMovies);

// PUT /api/movies/:id - Update movie
router.put('/:id', updateMovie);

// DELETE /api/movies/:id - Delete movie
router.delete('/:id', deleteMovie);

module.exports = router;

const mongoose = require('mongoose');

const movieSchema = new mongoose.Schema(
  {
    user: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      required: true
    },
    title: {
      type: String,
      required: [true, 'Please provide a movie title'],
      trim: true,
      minlength: [1, 'Title cannot be empty']
    },
    genre: {
      type: String,
      required: [true, 'Please provide a genre'],
      trim: true
    },
    year: {
      type: Number,
      required: [true, 'Please provide a year'],
      min: [1800, 'Year must be after 1800'],
      max: [new Date().getFullYear() + 5, 'Year cannot be in the distant future']
    },
    status: {
      type: String,
      enum: ['watched', 'unwatched'],
      default: 'unwatched',
      required: true
    }
  },
  { timestamps: true }
);

module.exports = mongoose.model('Movie', movieSchema);

# 🎬 Movie Watchlist API - Testing Guide

## ✅ Setup Instructions

### 1. Start MongoDB
```bash
mongod
```

### 2. Run the seed script (to add sample data)
```bash
node seed.js
```

Expected output:
```
✓ Users created:
  - John Doe (john@example.com)
  - Jane Smith (jane@example.com)
✓ Movies created:
  - 4 movies for John Doe
  - 3 movies for Jane Smith
```

### 3. Start the server
```bash
npm run dev
```

Server should run on: `http://localhost:5000`

---

## 🧪 Testing with Thunder Client

### Install Thunder Client
1. Go to VS Code Extensions
2. Search for "Thunder Client"
3. Click Install

### Import Collection
1. Open Thunder Client
2. Click "Collections" on left sidebar
3. Click "Import"
4. Select `thunder-collection.json` from the backend folder
5. All 8 test endpoints will be ready

---

## 📋 Test Cases (Step by Step)

### 1️⃣ **Register New User**
**Endpoint:** `POST` http://localhost:5000/api/auth/register

**Request Body:**
```json
{
  "name": "John Doe",
  "email": "john@example.com",
  "password": "password123"
}
```

**Expected Response (201):**
```json
{
  "success": true,
  "message": "User registered successfully",
  "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
  "user": {
    "id": "65854abc123...",
    "name": "John Doe",
    "email": "john@example.com"
  }
}
```

---

### 2️⃣ **Login User**
**Endpoint:** `POST` http://localhost:5000/api/auth/login

**Request Body:**
```json
{
  "email": "john@example.com",
  "password": "password123"
}
```

**Expected Response (200):**
```json
{
  "success": true,
  "message": "Logged in successfully",
  "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
  "user": {
    "id": "65854abc123...",
    "name": "John Doe",
    "email": "john@example.com"
  }
```

⚠️ **SAVE THIS TOKEN** - You'll need it for all other requests!

---

### 3️⃣ **Add Movie to Watchlist**
**Endpoint:** `POST` http://localhost:5000/api/movies

**Headers:**
```
Authorization: Bearer YOUR_JWT_TOKEN_HERE
Content-Type: application/json
```

**Request Body:**
```json
{
  "title": "Oppenheimer",
  "genre": "Biography",
  "year": 2023,
  "status": "unwatched"
}
```

**Expected Response (201):**
```json
{
  "success": true,
  "message": "Movie added to watchlist",
  "movie": {
    "_id": "65854def456...",
    "user": "65854abc123...",
    "title": "Oppenheimer",
    "genre": "Biography",
    "year": 2023,
    "status": "unwatched",
    "createdAt": "2025-12-16T10:30:00.000Z",
    "updatedAt": "2025-12-16T10:30:00.000Z"
  }
}
```

---

### 4️⃣ **Get All Movies (Watchlist)**
**Endpoint:** `GET` http://localhost:5000/api/movies

**Headers:**
```
Authorization: Bearer YOUR_JWT_TOKEN_HERE
```

**Expected Response (200):**
```json
{
  "success": true,
  "message": "Movies retrieved successfully",
  "count": 5,
  "movies": [
    {
      "_id": "65854def456...",
      "user": "65854abc123...",
      "title": "Oppenheimer",
      "genre": "Biography",
      "year": 2023,
      "status": "unwatched",
      "createdAt": "2025-12-16T10:30:00.000Z"
    },
    {
      "_id": "65854ghi789...",
      "user": "65854abc123...",
      "title": "The Shawshank Redemption",
      "genre": "Drama",
      "year": 1994,
      "status": "watched"
    }
  ]
}
```

---

### 5️⃣ **Update Movie Status**
**Endpoint:** `PUT` http://localhost:5000/api/movies/{MOVIE_ID}

Replace `{MOVIE_ID}` with actual movie ID from Get All Movies response

**Headers:**
```
Authorization: Bearer YOUR_JWT_TOKEN_HERE
Content-Type: application/json
```

**Request Body:**
```json
{
  "status": "watched"
}
```

**Expected Response (200):**
```json
{
  "success": true,
  "message": "Movie updated successfully",
  "movie": {
    "_id": "65854def456...",
    "user": "65854abc123...",
    "title": "Oppenheimer",
    "genre": "Biography",
    "year": 2023,
    "status": "watched",
    "updatedAt": "2025-12-16T10:35:00.000Z"
  }
}
```

---

### 6️⃣ **Delete Movie**
**Endpoint:** `DELETE` http://localhost:5000/api/movies/{MOVIE_ID}

Replace `{MOVIE_ID}` with actual movie ID

**Headers:**
```
Authorization: Bearer YOUR_JWT_TOKEN_HERE
```

**Expected Response (200):**
```json
{
  "success": true,
  "message": "Movie deleted successfully"
}
```

---

## ⚠️ Error Test Cases

### Invalid Token
**Send:** `GET` http://localhost:5000/api/movies
**Headers:** `Authorization: Bearer invalid_token`

**Response (401):**
```json
{
  "success": false,
  "message": "Invalid or expired token"
}
```

### Missing Required Fields
**Send:** `POST` http://localhost:5000/api/movies
**Body:** `{"title": "Test"}`

**Response (400):**
```json
{
  "success": false,
  "message": "Please provide title, genre, and year"
}
```

### Invalid Email
**Send:** `POST` http://localhost:5000/api/auth/register
**Body:**
```json
{
  "name": "Test",
  "email": "invalid-email",
  "password": "test123"
}
```

**Response (500):**
```json
{
  "success": false,
  "message": "..."
}
```

---

## 🚀 Quick Test Workflow

1. **Run seed.js** to add sample data
2. **Login** with `john@example.com / password123`
3. **Copy the token** from response
4. **Get all movies** (should see 4 movies)
5. **Add a new movie** (e.g., Oppenheimer)
6. **Update a movie** status from unwatched → watched
7. **Delete a movie**
8. **Get all movies** again (verify deletion)

---

## 📝 Sample Data Credentials

After running `seed.js`:

| User | Email | Password | Movies |
|------|-------|----------|--------|
| John Doe | john@example.com | password123 | 4 movies |
| Jane Smith | jane@example.com | password456 | 3 movies |

---

## 🐛 Troubleshooting

**Error: Cannot connect to MongoDB**
- Ensure MongoDB is running: `mongod`

**Error: Port 5000 already in use**
- Change `PORT` in `.env` file

**Error: Invalid token**
- Login again and get a new token
- Token expires in 30 days

**Error: Movie not found**
- Ensure movie ID is correct
- Verify you're using the right token (movie belongs to logged-in user)

---

**All endpoints are fully functional and ready for testing! ✅**

const dotenv = require('dotenv');
dotenv.config();

(async () => {
  try {
    const url = `http://localhost:${process.env.PORT || 5000}/api/auth/login`;
    const payload = { email: 'john@example.com', password: 'password123' };

    const res = await fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
    });

    const body = await res.json();
    console.log('Status:', res.status);
    console.log('Response:', JSON.stringify(body, null, 2));
  } catch (err) {
    console.error('Error:', err.message);
    process.exit(1);
  }
})();

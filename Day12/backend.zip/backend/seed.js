const dotenv = require('dotenv');
const mongoose = require('mongoose');
const User = require('./src/models/User');
const Movie = require('./src/models/Movie');

dotenv.config();

const seedData = async () => {
  try {
    // Connect to database
    await mongoose.connect(process.env.MONGO_URI, {
      useNewUrlParser: true,
      useUnifiedTopology: true
    });
    console.log('MongoDB Connected');

    // Clear existing data
    await User.deleteMany({});
    await Movie.deleteMany({});
    console.log('Cleared existing data');

    // Create sample users
    const user1 = await User.create({
      name: 'John Doe',
      email: 'john@example.com',
      password: 'password123'
    });

    const user2 = await User.create({
      name: 'Jane Smith',
      email: 'jane@example.com',
      password: 'password456'
    });

    console.log('✓ Users created:');
    console.log(`  - ${user1.name} (${user1.email})`);
    console.log(`  - ${user2.name} (${user2.email})`);

    // Create sample movies for user1
    const movies1 = await Movie.insertMany([
      {
        user: user1._id,
        title: 'The Shawshank Redemption',
        genre: 'Drama',
        year: 1994,
        status: 'watched'
      },
      {
        user: user1._id,
        title: 'Inception',
        genre: 'Sci-Fi',
        year: 2010,
        status: 'watched'
      },
      {
        user: user1._id,
        title: 'Dune',
        genre: 'Sci-Fi',
        year: 2021,
        status: 'unwatched'
      },
      {
        user: user1._id,
        title: 'The Dark Knight',
        genre: 'Action',
        year: 2008,
        status: 'watched'
      }
    ]);

    // Create sample movies for user2
    const movies2 = await Movie.insertMany([
      {
        user: user2._id,
        title: 'Forrest Gump',
        genre: 'Drama',
        year: 1994,
        status: 'watched'
      },
      {
        user: user2._id,
        title: 'The Matrix',
        genre: 'Sci-Fi',
        year: 1999,
        status: 'watched'
      },
      {
        user: user2._id,
        title: 'Avatar',
        genre: 'Sci-Fi',
        year: 2009,
        status: 'unwatched'
      }
    ]);

    console.log('✓ Movies created:');
    console.log(`  - ${movies1.length} movies for ${user1.name}`);
    console.log(`  - ${movies2.length} movies for ${user2.name}`);

    console.log('\n✅ Seed data inserted successfully!');
    console.log('\n📋 TEST CREDENTIALS:');
    console.log('User 1: john@example.com / password123');
    console.log('User 2: jane@example.com / password456');

    process.exit(0);
  } catch (error) {
    console.error('❌ Error seeding data:', error.message);
    process.exit(1);
  }
};

seedData();

const dotenv = require('dotenv');
const mongoose = require('mongoose');
const User = require('./src/models/User');
const Movie = require('./src/models/Movie');

dotenv.config();

(async () => {
  try {
    await mongoose.connect(process.env.MONGO_URI, { useNewUrlParser: true, useUnifiedTopology: true });

    const user = await User.findOne({ email: 'john@example.com' });
    if (!user) {
      console.error('User not found');
      process.exit(1);
    }

    const movies = await Movie.find({ user: user._id }).sort({ createdAt: -1 });

    const out = {
      success: true,
      message: 'Movies retrieved successfully',
      count: movies.length,
      movies
    };

    console.log(JSON.stringify(out, null, 2));
    process.exit(0);
  } catch (err) {
    console.error(err);
    process.exit(1);
  }
})();
